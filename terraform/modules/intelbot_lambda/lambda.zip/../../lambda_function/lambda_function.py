#!/usr/bin/env python3

from lambda_function.lambdabot import LambdaBot

def handler(event, context):
    lb = LambdaBot()
    lb.process_event(event)
    ## Insert actual code do do interesting things here
    ## event is exposed by lb.event.event. (or lb.event) for meta data
    #dummy response just echos back the user input in reverse.  Good for testing
    lb.dummy_response()