zip -r9 lambda.zip *
aws lambda update-function-code --function-name privbot-handle-event --region us-east-1 --zip-file fileb://lambda.zip
